#include<stdio.h>
int main(){

    int h, i, j;
    printf("nhap chieu cao h:");
    scanf("%d",&h);
    //i la so dong
    for (int i=1; i<=h ; i++)//vong lap ngoai cung duyet tung dong
    {
        for(int j = 1; j<=h-i;j++) //vong lap in khoang trang ben trai tam giac
        {
           printf(" ");
        }
        for (int j = 1; j<=2*i-1;j++) // vong lap in dau sao
        {
            printf("*");
        }
       printf("\n"); // xuong dong
    }

}