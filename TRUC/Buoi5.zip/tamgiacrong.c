#include <stdio.h>

int main() {
    int h;
    printf("nhap chieu cao h: ");
    scanf("%d", &h);
// vòng lặp qua từng dòng
    for (int i = 1; i <= h; i++) {
        // in khoảng trắng bên trái
        for (int j = 1; j <= h - i; j++) {
            printf(" ");
        }

        // in dấu *
        for (int j = 1; j <= 2 * i - 1; j++) {
            if (j == 1 || j == 2 * i - 1 || i == h) {
                printf("*");  // cạnh trái, cạnh phải, hoặc đáy
            } else {
                printf(" ");  // phần rỗng bên trong
            }
        }

        printf("\n"); // xuống dòng
    }

    return 0;
}
