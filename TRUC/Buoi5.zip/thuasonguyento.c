#include <stdio.h>

int main() {
    int n, i;
    printf("Nhap mot so nguyen duong: ");
    scanf("%d", &n);

    printf("%d = ", n);

    i = 2; // bắt đầu từ số nguyên tố nhỏ nhất
    while (n > 1) {
        if (n % i == 0) {
            printf("%d", i);   // in ra thừa số i
            n = n / i;         // giảm n xuống
            if (n > 1) printf(" * "); // in dấu * nếu còn tiếp
        } else {
            i++; // tăng i để thử thừa số tiếp theo
        }
    }

    printf("\n");
    return 0;
}
