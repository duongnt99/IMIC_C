#include<stdio.h>
int main ()
{
    int choice;
    double balance = 500000; //so du ban dau 500k
    double amount;
    do{
        printf("1.kiem tra so du\n");
        printf("2.rut tien\n");
        printf("3.nap tien\n");
        printf("4.thoat\n");
        printf("chon chuc nang 1-4");
        scanf("%d",&choice);

        switch(choice)
        {
            case 1:
                printf("so du hien tai la %.0f VND\n",balance);
                break;
            case 2:
                printf("nhap so tien can rut:");
                scanf("%lf",&amount);
                if (amount>balance) {
                    printf("so du tai khoan ko du\n");
                }else if (amount<=0){
                    printf("so tien ko hop le");
                }else {
                    balance -= amount;
                    printf("rut thanh cong, so tien con lai la %.0f VND\n",balance);
                } 
                break;
            case 3:
                printf("so tien nap:");
                scanf("%lf",&amount);
                if(amount>0){
                    balance += amount;
                    printf("nap thanh cong. so du hien tai la %.0f VND\n",balance);
            
                }else {
                    printf("so tien ko hop le");
                }
                break;
            case 4:
                printf("cam on ban da su dung dich vu ATM\n");    
                break;
            default:
            printf("lua chon ko hop le, vui long chon lai\n");    
        }

    }while(choice != 4);
return 0;    
}