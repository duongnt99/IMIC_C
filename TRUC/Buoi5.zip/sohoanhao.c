#include <stdio.h>

int main() {
    int n, i, sum;

    printf("Cac so hoan hao tu 1 den 10000 la:\n");

    // duyệt từng số từ 1 đến 10000
    for (n = 1; n <= 10000; n++) {
        sum = 0; // tổng ước của n

        // tìm ước số của n (không tính chính nó)
        for (i = 1; i <= n/2; i++) { 
            if (n % i == 0) { 
                sum += i; // cộng vào tổng nếu i là ước
            }
        }

        // kiểm tra có phải số hoàn hảo không
        if (sum == n && n != 0) {
            printf("%d ", n);
        }
    }

    return 0;
}
